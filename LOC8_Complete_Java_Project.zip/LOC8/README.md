# LOC8 – Smart Campus Assistance Platform

A Java 17 desktop application built with Swing. It contains three modules:

1. Lost & Found Management
2. Smart Campus Search
3. Emergency Contacts

## Requirements
- JDK 17 or later
- Windows, macOS, or Linux
- No third-party libraries and no internet connection required at runtime

## Run
Open a terminal in the project folder and run:

```bash
javac -d out src/loc8/*.java src/loc8/model/*.java src/loc8/io/*.java src/loc8/service/*.java src/loc8/ui/*.java
java -cp out loc8.LOC8App
```

On Windows PowerShell, the same commands work if `javac` and `java` are on PATH.

Alternatively, open the folder in IntelliJ IDEA or Eclipse and run `loc8.LOC8App`.

## Data files
The application creates and uses:
- `data/items.dat` – saved Lost & Found records
- `data/locations.csv` – campus directory
- `data/emergency.csv` – emergency contacts
- `data/images/` – copied item photographs

The CSV files are seeded with example campus data. Replace these examples with your institution's actual information.

**Important:** `Campus Security` and `Campus Medical Room` use placeholder phone numbers. Replace them with verified campus numbers before using the application in real life.

## Project structure
```text
LOC8/
├── src/loc8/LOC8App.java
├── src/loc8/model/
├── src/loc8/io/
├── src/loc8/service/
├── src/loc8/ui/
└── data/
```

## Scope
This version is a local, single-computer desktop application. It does not include user accounts, cloud synchronisation, shared databases, GPS/live maps, or SMS/email notifications, matching the scope in the project report.
