#!/bin/sh
mkdir -p out
javac -d out src/loc8/*.java src/loc8/model/*.java src/loc8/io/*.java src/loc8/service/*.java src/loc8/ui/*.java
if [ $? -ne 0 ]; then exit 1; fi
java -cp out loc8.LOC8App
