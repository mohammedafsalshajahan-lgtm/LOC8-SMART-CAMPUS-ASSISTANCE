package loc8.service;

import loc8.model.CampusEntity;
import java.util.List;
import java.util.stream.Collectors;

public class SearchService {
    public <T extends CampusEntity> List<T> search(List<T> source, String query) {
        return source.stream().filter(item -> item.matches(query)).collect(Collectors.toList());
    }
}
