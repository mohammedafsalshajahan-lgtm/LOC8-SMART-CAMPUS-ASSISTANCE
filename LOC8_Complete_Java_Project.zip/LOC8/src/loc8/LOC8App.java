package loc8;

import loc8.io.DataStore;
import loc8.ui.*;

import javax.swing.*;
import java.awt.*;

public class LOC8App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Theme.apply();
            try {
                DataStore store = new DataStore();
                JFrame frame = new JFrame("LOC8 – Smart Campus Assistance Platform");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setMinimumSize(new Dimension(900, 600));
                frame.setSize(1100, 700);
                frame.setLocationRelativeTo(null);

                JPanel root = new JPanel(new BorderLayout());
                root.setBackground(Theme.BG);
                JPanel banner = new JPanel(new BorderLayout());
                banner.setBackground(Theme.NAVY);
                banner.setBorder(BorderFactory.createEmptyBorder(16, 22, 16, 22));
                JLabel brand = new JLabel("LOC8");
                brand.setForeground(Color.WHITE);
                brand.setFont(new Font("SansSerif", Font.BOLD, 27));
                JLabel tagline = new JLabel("SMART CAMPUS ASSISTANCE PLATFORM");
                tagline.setForeground(new Color(220, 230, 245));
                tagline.setFont(new Font("SansSerif", Font.PLAIN, 12));
                JPanel titles = new JPanel();
                titles.setOpaque(false);
                titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
                titles.add(brand); titles.add(tagline);
                banner.add(titles, BorderLayout.WEST);
                root.add(banner, BorderLayout.NORTH);

                JTabbedPane tabs = new JTabbedPane();
                tabs.addTab("Lost & Found", new LostFoundPanel(store));
                tabs.addTab("Campus Search", new CampusSearchPanel(store));
                tabs.addTab("Emergency Contacts", new EmergencyContactsPanel(store));
                root.add(tabs, BorderLayout.CENTER);

                JLabel footer = new JLabel("  LOC8  |  Local desktop application  |  Java Swing");
                footer.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
                root.add(footer, BorderLayout.SOUTH);
                frame.setContentPane(root);
                frame.setVisible(true);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "LOC8 could not start: " + ex.getMessage(),
                        "Startup Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
    }
}
