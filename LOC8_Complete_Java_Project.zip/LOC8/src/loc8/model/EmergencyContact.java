package loc8.model;

public class EmergencyContact extends CampusEntity {
    private static final long serialVersionUID = 1L;
    private final String phone;

    public EmergencyContact(String name, String phone, String description) {
        super(name, description);
        this.phone = phone;
    }

    public String getPhone() { return phone; }

    @Override
    public boolean matches(String query) {
        if (query == null || query.isBlank()) return true;
        String q = query.toLowerCase();
        return super.matches(q) || phone.toLowerCase().contains(q);
    }

    @Override
    public String summary() {
        return getName() + " — " + phone;
    }
}
