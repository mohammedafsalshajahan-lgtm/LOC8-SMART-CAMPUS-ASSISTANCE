package loc8.model;

public class CampusLocation extends CampusEntity {
    private static final long serialVersionUID = 1L;
    private final String category;
    private final String building;

    public CampusLocation(String name, String category, String building, String description) {
        super(name, description);
        this.category = category;
        this.building = building;
    }

    public String getCategory() { return category; }
    public String getBuilding() { return building; }

    @Override
    public boolean matches(String query) {
        if (query == null || query.isBlank()) return true;
        String q = query.toLowerCase();
        return super.matches(q) || category.toLowerCase().contains(q)
                || building.toLowerCase().contains(q);
    }

    @Override
    public String summary() {
        return getName() + " (" + category + ") — " + building;
    }
}
