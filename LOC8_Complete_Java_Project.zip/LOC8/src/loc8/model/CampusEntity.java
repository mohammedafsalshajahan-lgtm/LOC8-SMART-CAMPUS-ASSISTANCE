package loc8.model;

import java.io.Serializable;

public abstract class CampusEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private final String name;
    private final String description;

    protected CampusEntity(String name, String description) {
        this.name = name == null ? "" : name.trim();
        this.description = description == null ? "" : description.trim();
    }

    public String getName() { return name; }
    public String getDescription() { return description; }

    public boolean matches(String query) {
        if (query == null || query.isBlank()) return true;
        String q = query.toLowerCase();
        return name.toLowerCase().contains(q) || description.toLowerCase().contains(q);
    }

    public abstract String summary();

    @Override
    public String toString() { return summary(); }
}
