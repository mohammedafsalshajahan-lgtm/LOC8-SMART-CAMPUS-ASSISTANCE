package loc8.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class LostItem extends CampusEntity {
    private static final long serialVersionUID = 1L;
    private final String id;
    private final String type;
    private final String category;
    private final String place;
    private final String contact;
    private final String imagePath;
    private final LocalDateTime dateReported;
    private boolean recovered;

    public LostItem(String type, String name, String category, String description,
                    String place, String contact, String imagePath) {
        super(name, description);
        this.id = UUID.randomUUID().toString();
        this.type = type;
        this.category = category;
        this.place = place;
        this.contact = contact;
        this.imagePath = imagePath == null ? "" : imagePath;
        this.dateReported = LocalDateTime.now();
        this.recovered = false;
    }

    public String getId() { return id; }
    public String getType() { return type; }
    public String getCategory() { return category; }
    public String getPlace() { return place; }
    public String getContact() { return contact; }
    public String getImagePath() { return imagePath; }
    public LocalDateTime getDateReported() { return dateReported; }
    public boolean isRecovered() { return recovered; }
    public void setRecovered(boolean recovered) { this.recovered = recovered; }

    @Override
    public boolean matches(String query) {
        if (query == null || query.isBlank()) return true;
        String q = query.toLowerCase();
        return super.matches(q) || category.toLowerCase().contains(q)
                || place.toLowerCase().contains(q) || type.toLowerCase().contains(q);
    }

    @Override
    public String summary() {
        return type + " | " + getName() + " | " + place + (recovered ? " | Recovered" : "");
    }

    public String getDateText() {
        return dateReported.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));
    }
}
