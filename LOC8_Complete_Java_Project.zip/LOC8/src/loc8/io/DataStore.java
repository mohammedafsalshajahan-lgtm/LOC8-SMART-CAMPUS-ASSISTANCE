package loc8.io;

import loc8.model.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class DataStore {
    private final Path dataDir = Paths.get("data");
    private final Path itemsFile = dataDir.resolve("items.dat");
    private final Path locationsFile = dataDir.resolve("locations.csv");
    private final Path emergencyFile = dataDir.resolve("emergency.csv");
    private final Path imagesDir = dataDir.resolve("images");

    public DataStore() throws IOException {
        Files.createDirectories(imagesDir);
        seedIfMissing(locationsFile, "# name,category,building,description\n"
                + "Central Library,Library,Main Block,Books and reading hall\n"
                + "Boys Hostel,Hostel,Hostel Area,Student accommodation\n"
                + "Computer Science Department,Department,Academic Block A,Department office and classrooms\n"
                + "Computer Lab 1,Lab,Academic Block A,Computer programming laboratory\n"
                + "College Canteen,Canteen,Canteen Block,Food and refreshments\n"
                + "Main Parking,Parking,Main Gate,Vehicle parking area\n");
        seedIfMissing(emergencyFile, "# name,phone,description\n"
                + "National Emergency Number,112,All-in-one national emergency response\n"
                + "Police,100,Police emergency assistance\n"
                + "Fire and Rescue,101,Fire and rescue services\n"
                + "Ambulance,108,Emergency ambulance service\n"
                + "Campus Security,0000000000,Replace with verified campus number\n"
                + "Campus Medical Room,0000000000,Replace with verified campus number\n");
    }

    private void seedIfMissing(Path path, String content) throws IOException {
        if (Files.notExists(path)) Files.writeString(path, content);
    }

    @SuppressWarnings("unchecked")
    public List<LostItem> loadItems() {
        if (Files.notExists(itemsFile)) return new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(itemsFile))) {
            Object value = in.readObject();
            if (value instanceof ArrayList<?>) return (ArrayList<LostItem>) value;
        } catch (IOException | ClassNotFoundException | ClassCastException ex) {
            System.err.println("Could not read saved item data: " + ex.getMessage());
            try {
                Files.move(itemsFile, itemsFile.resolveSibling("items-corrupt-" + System.currentTimeMillis() + ".dat"),
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ignored) {}
        }
        return new ArrayList<>();
    }

    public void saveItems(List<LostItem> items) throws IOException {
        Path temp = dataDir.resolve("items.tmp");
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(temp))) {
            out.writeObject(new ArrayList<>(items));
        }
        try {
            Files.move(temp, itemsFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ex) {
            Files.move(temp, itemsFile, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public List<CampusLocation> loadLocations() throws IOException {
        List<CampusLocation> result = new ArrayList<>();
        for (String line : Files.readAllLines(locationsFile)) {
            if (line.isBlank() || line.stripLeading().startsWith("#")) continue;
            try {
                List<String> p = CsvUtil.parseLine(line);
                if (p.size() >= 4) result.add(new CampusLocation(p.get(0), p.get(1), p.get(2), p.get(3)));
            } catch (RuntimeException ex) {
                System.err.println("Skipping malformed location row: " + line);
            }
        }
        return result;
    }

    public List<EmergencyContact> loadEmergencyContacts() throws IOException {
        List<EmergencyContact> result = new ArrayList<>();
        for (String line : Files.readAllLines(emergencyFile)) {
            if (line.isBlank() || line.stripLeading().startsWith("#")) continue;
            try {
                List<String> p = CsvUtil.parseLine(line);
                if (p.size() >= 3) result.add(new EmergencyContact(p.get(0), p.get(1), p.get(2)));
            } catch (RuntimeException ex) {
                System.err.println("Skipping malformed emergency row: " + line);
            }
        }
        return result;
    }

    public String copyImage(Path source) throws IOException {
        String fileName = UUID.randomUUID() + getSafeExtension(source.getFileName().toString());
        Path destination = imagesDir.resolve(fileName);
        Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
        return destination.toString();
    }

    private String getSafeExtension(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0) return ".img";
        String ext = name.substring(dot).toLowerCase();
        return ext.matches("\\.(jpg|jpeg|png|gif)") ? ext : ".img";
    }
}
