package loc8.ui;

import loc8.io.DataStore;
import loc8.model.CampusLocation;
import loc8.service.SearchService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CampusSearchPanel extends JPanel {
    private final SearchService search = new SearchService();
    private final List<CampusLocation> locations;
    private final DefaultListModel<CampusLocation> listModel = new DefaultListModel<>();
    private final JList<CampusLocation> list = new JList<>(listModel);
    private final JTextArea details = new JTextArea();

    public CampusSearchPanel(DataStore store) throws Exception {
        locations = store.loadLocations();
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        setBackground(Theme.BG);

        JLabel heading = new JLabel("Smart Campus Search");
        heading.setFont(new Font("SansSerif", Font.BOLD, 20));
        JTextField query = new JTextField(22);
        JButton searchButton = Theme.button("Search");
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setOpaque(false);
        top.add(heading); top.add(Box.createHorizontalStrut(20));
        top.add(new JLabel("Search campus:")); top.add(query); top.add(searchButton);
        add(top, BorderLayout.NORTH);

        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        details.setEditable(false);
        details.setLineWrap(true);
        details.setWrapStyleWord(true);
        details.setFont(new Font("SansSerif", Font.PLAIN, 14));
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(list),
                new JScrollPane(details));
        split.setResizeWeight(0.55);
        add(split, BorderLayout.CENTER);

        searchButton.addActionListener(e -> refresh(query.getText()));
        query.addActionListener(e -> refresh(query.getText()));
        list.addListSelectionListener(e -> {
            CampusLocation item = list.getSelectedValue();
            if (item != null) details.setText("LOCATION DETAILS\n\nName: " + item.getName()
                    + "\nCategory: " + item.getCategory() + "\nBuilding/Area: " + item.getBuilding()
                    + "\n\nDescription:\n" + item.getDescription());
        });
        refresh("");
    }

    private void refresh(String q) {
        listModel.clear();
        for (CampusLocation location : search.search(locations, q)) listModel.addElement(location);
        details.setText("Select a campus location to see its details.");
    }
}
