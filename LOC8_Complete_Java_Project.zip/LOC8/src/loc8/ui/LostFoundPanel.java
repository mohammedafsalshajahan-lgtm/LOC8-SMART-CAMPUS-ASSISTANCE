package loc8.ui;

import loc8.io.DataStore;
import loc8.model.LostItem;
import loc8.service.SearchService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class LostFoundPanel extends JPanel {
    private final DataStore store;
    private final SearchService search = new SearchService();
    private final List<LostItem> items;
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Type", "Item", "Category", "Place", "Contact", "Reported", "Status"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField searchField = new JTextField(18);

    public LostFoundPanel(DataStore store) {
        this.store = store;
        this.items = store.loadItems();
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        setBackground(Theme.BG);

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel heading = new JLabel("Lost & Found Management");
        heading.setFont(new Font("SansSerif", Font.BOLD, 20));
        top.add(heading, BorderLayout.NORTH);
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchBar.setOpaque(false);
        searchBar.add(new JLabel("Search:"));
        searchBar.add(searchField);
        JButton find = Theme.button("Search");
        JButton reset = new JButton("Show All");
        searchBar.add(find);
        searchBar.add(reset);
        top.add(searchBar, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        table.setRowHeight(26);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        actions.setOpaque(false);
        JButton reportLost = Theme.button("Report Lost Item");
        JButton reportFound = Theme.button("Report Found Item");
        JButton recovered = Theme.button("Mark Recovered");
        JButton delete = new JButton("Delete Selected");
        actions.add(reportLost); actions.add(reportFound); actions.add(recovered); actions.add(delete);
        add(actions, BorderLayout.SOUTH);

        find.addActionListener(e -> refresh(searchField.getText()));
        reset.addActionListener(e -> { searchField.setText(""); refresh(""); });
        reportLost.addActionListener(e -> addItem("LOST"));
        reportFound.addActionListener(e -> addItem("FOUND"));
        recovered.addActionListener(e -> markRecovered());
        delete.addActionListener(e -> deleteSelected());
        refresh("");
    }

    private void addItem(String type) {
        JTextField name = new JTextField();
        JTextField category = new JTextField();
        JTextField place = new JTextField();
        JTextField contact = new JTextField();
        JTextArea description = new JTextArea(3, 20);
        description.setLineWrap(true);
        JLabel imageLabel = new JLabel("No image selected");
        final Path[] image = {null};
        JButton chooseImage = new JButton("Choose Image (optional)");
        chooseImage.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                image[0] = chooser.getSelectedFile().toPath();
                imageLabel.setText(image[0].getFileName().toString());
            }
        });

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 7));
        form.add(new JLabel("Item name *")); form.add(name);
        form.add(new JLabel("Category")); form.add(category);
        form.add(new JLabel("Place *")); form.add(place);
        form.add(new JLabel("Contact *")); form.add(contact);
        form.add(new JLabel("Description")); form.add(new JScrollPane(description));
        form.add(chooseImage); form.add(imageLabel);

        int result = JOptionPane.showConfirmDialog(this, form, "Report " + type + " Item",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;
        if (name.getText().isBlank() || place.getText().isBlank() || contact.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Item name, place and contact are required.");
            return;
        }
        try {
            String imagePath = image[0] == null ? "" : store.copyImage(image[0]);
            items.add(new LostItem(type, name.getText(), category.getText(), description.getText(),
                    place.getText(), contact.getText(), imagePath));
            save();
            refresh(searchField.getText());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Could not save report: " + ex.getMessage());
        }
    }

    private void markRecovered() {
        int row = table.getSelectedRow();
        if (row < 0) { warnSelect(); return; }
        String shownName = String.valueOf(model.getValueAt(row, 1));
        LostItem item = visibleItems().get(row);
        item.setRecovered(true);
        save();
        refresh(searchField.getText());
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { warnSelect(); return; }
        LostItem item = visibleItems().get(row);
        if (JOptionPane.showConfirmDialog(this, "Delete this report?", "Confirm",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            items.remove(item);
            save();
            refresh(searchField.getText());
        }
    }

    private List<LostItem> visibleItems() { return search.search(items, searchField.getText()); }

    private void save() {
        try { store.saveItems(items); }
        catch (Exception ex) { JOptionPane.showMessageDialog(this, "Save failed: " + ex.getMessage()); }
    }

    private void refresh(String query) {
        model.setRowCount(0);
        for (LostItem item : search.search(items, query)) {
            model.addRow(new Object[]{item.getType(), item.getName(), item.getCategory(), item.getPlace(),
                    item.getContact(), item.getDateText(), item.isRecovered() ? "Recovered" : "Open"});
        }
    }

    private void warnSelect() {
        JOptionPane.showMessageDialog(this, "Please select a report first.");
    }
}
