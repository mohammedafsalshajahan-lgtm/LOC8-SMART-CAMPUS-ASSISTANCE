package loc8.ui;

import loc8.io.DataStore;
import loc8.model.EmergencyContact;
import loc8.service.SearchService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class EmergencyContactsPanel extends JPanel {
    private final SearchService search = new SearchService();
    private final List<EmergencyContact> contacts;
    private final DefaultListModel<EmergencyContact> listModel = new DefaultListModel<>();
    private final JList<EmergencyContact> list = new JList<>(listModel);
    private final JTextArea details = new JTextArea();

    public EmergencyContactsPanel(DataStore store) throws Exception {
        contacts = store.loadEmergencyContacts();
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        setBackground(Theme.BG);

        JLabel heading = new JLabel("Emergency Contacts");
        heading.setFont(new Font("SansSerif", Font.BOLD, 20));
        JTextField query = new JTextField(22);
        JButton searchButton = Theme.button("Search");
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setOpaque(false);
        top.add(heading); top.add(Box.createHorizontalStrut(20));
        top.add(new JLabel("Search:")); top.add(query); top.add(searchButton);
        add(top, BorderLayout.NORTH);

        details.setEditable(false);
        details.setFont(new Font("SansSerif", Font.PLAIN, 14));
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(list),
                new JScrollPane(details));
        split.setResizeWeight(0.55);
        add(split, BorderLayout.CENTER);

        searchButton.addActionListener(e -> refresh(query.getText()));
        query.addActionListener(e -> refresh(query.getText()));
        list.addListSelectionListener(e -> {
            EmergencyContact item = list.getSelectedValue();
            if (item != null) details.setText("CONTACT DETAILS\n\nName: " + item.getName()
                    + "\nPhone: " + item.getPhone() + "\n\nPurpose:\n" + item.getDescription());
        });
        refresh("");
    }

    private void refresh(String q) {
        listModel.clear();
        for (EmergencyContact contact : search.search(contacts, q)) listModel.addElement(contact);
        details.setText("Select a contact to see details.");
    }
}
