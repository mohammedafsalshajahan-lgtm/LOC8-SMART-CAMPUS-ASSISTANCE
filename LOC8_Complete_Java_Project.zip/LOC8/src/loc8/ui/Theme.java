package loc8.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public final class Theme {
    public static final Color NAVY = new Color(25, 43, 75);
    public static final Color BLUE = new Color(42, 112, 190);
    public static final Color BG = new Color(245, 247, 251);
    public static final Color TEXT = new Color(38, 48, 63);

    private Theme() {}

    public static void apply() {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        UIManager.put("Panel.background", BG);
        UIManager.put("TabbedPane.selected", Color.WHITE);
        UIManager.put("Button.background", BLUE);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.font", new Font("SansSerif", Font.BOLD, 13));
        UIManager.put("Label.foreground", TEXT);
    }

    public static JPanel page(String title, String subtitle) {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBorder(new EmptyBorder(18, 18, 18, 18));
        panel.setBackground(BG);
        JPanel heading = new JPanel();
        heading.setOpaque(false);
        heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));
        JLabel h = new JLabel(title);
        h.setFont(new Font("SansSerif", Font.BOLD, 22));
        h.setForeground(NAVY);
        JLabel s = new JLabel(subtitle);
        s.setFont(new Font("SansSerif", Font.PLAIN, 13));
        heading.add(h);
        heading.add(Box.createVerticalStrut(5));
        heading.add(s);
        panel.add(heading, BorderLayout.NORTH);
        return panel;
    }

    public static JButton button(String text) {
        JButton b = new JButton(text);
        b.setFocusPainted(false);
        b.setBackground(BLUE);
        b.setForeground(Color.WHITE);
        return b;
    }
}
