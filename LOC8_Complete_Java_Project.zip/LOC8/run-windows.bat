@echo off
if not exist out mkdir out
javac -d out src\loc8\*.java src\loc8\model\*.java src\loc8\io\*.java src\loc8\service\*.java src\loc8\ui\*.java
if errorlevel 1 pause & exit /b 1
java -cp out loc8.LOC8App
pause
